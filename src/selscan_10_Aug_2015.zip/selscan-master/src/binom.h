#ifndef __BINOM_H__
#define __BINOM_H__
#include <cmath>

long double gammaln(long double);
long double factln(int);
long double nCk(int, int);
long double fact(int x);

#endif
