

#define CAN_READ_WRITE_x86_IEEE 0

extern char isCPULittleEndian;
extern char isCPUBigEndian;


/* Name of package */
#define PACKAGE "libsndfile"

/* Version number of package */
#define VERSION "0.0.17"

