#ifndef GLOBALSLINUX_H
#define GLOBALSLINUX_H

double GetRAMSizeMB();

#endif
