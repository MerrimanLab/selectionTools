#ifndef RAN1_H
#define RAN1_H

float ran1(long *idum);

#endif
