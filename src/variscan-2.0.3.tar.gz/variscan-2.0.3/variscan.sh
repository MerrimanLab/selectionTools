#!/bin/sh
export LWPATH=`pwd`/LastWave_2_0_4
export LWSOURCEDIR=`pwd`/LastWave_2_0_4/scripts
java -jar GUI/VariScanGUI.jar
