get.biallelic.matrix <- function(object, region){

return(popGetBial(object,region))

}
