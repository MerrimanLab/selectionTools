concatenate.classes <- function(classlist)
{

n.classes <- length(classlist)

return(concatenate(classlist, n.classes))

}
