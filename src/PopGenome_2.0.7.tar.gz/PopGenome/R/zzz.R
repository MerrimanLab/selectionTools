#.onLoad <- function(lib,pkg){

#.First.lib <- function(lib,pkg){

  #library.dynam("PopGenome.so",package="PopGenome")

 # library.dynam("PopGenome",package="PopGenome")

#}

