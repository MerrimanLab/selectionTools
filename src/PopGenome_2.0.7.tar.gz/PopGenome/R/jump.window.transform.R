setGeneric("jump.window.transform", function(object,subsites=FALSE) standardGeneric("jump.window.transform"))
 setMethod("jump.window.transform", "GENOME",

 function(object,subsites){


if(subsites=="gene"){


}


})

