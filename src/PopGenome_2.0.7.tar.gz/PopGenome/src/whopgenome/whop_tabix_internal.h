/*
**
**		WhopGen
**
**		WHOle genome population genetics with popGEN
**
**
**
**
**
**

	TODO:






**
*/

//*
//*			INCLUDES
//*

#include	"whopgen_common.h"

//*
//*			DEFINES
//*



//*
//*			STRUCTS
//*



//*
//*			CLASSES
//*



